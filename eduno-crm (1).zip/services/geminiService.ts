import { GoogleGenAI } from "@google/genai";
import { AttendanceRecord, AuditLog, User } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateAttendanceInsights = async (
  records: AttendanceRecord[],
  users: User[],
  auditLogs: AuditLog[],
  query: string
): Promise<string> => {
  // Prepare context data (summarized to save tokens)
  const dataContext = JSON.stringify({
    totalUsers: users.length,
    activeRecordsToday: records.filter(r => r.date === new Date().toISOString().split('T')[0]).length,
    recentLogs: auditLogs.slice(0, 10),
    sampleRecords: records.slice(0, 20), // Limit for context
  });

  try {
    const model = 'gemini-2.5-flash';
    const prompt = `
      You are an AI analyst for a student attendance CRM.
      Here is the current system snapshot (JSON):
      ${dataContext}

      User Query: "${query}"

      Provide a concise, professional, and actionable insight or answer based on the data.
      If analyzing anomalies, look for irregular check-in times or missing check-outs.
      Format the response in Markdown.
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });

    return response.text || "No insights could be generated at this time.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I encountered an issue analyzing the data. Please try again later.";
  }
};